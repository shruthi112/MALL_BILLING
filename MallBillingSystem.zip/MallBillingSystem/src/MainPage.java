import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class MainPage extends JFrame implements ActionListener{

	JPanel panel,panel1,panel2,panel3,panel4;
	JButton GenerateBill,ProductList,Taxdata,BilledData;
	JTextField field ;
	JLabel label;
	MainPage(){
		//	JFrame frame=new JFrame("Mall Billing System");
		super ("Mall Billing System Based on GST");

		//setSize(300,100);
		this.setVisible(true);
		this.setBounds(0, 0, 1000, 1000);
		this.setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		panel=new JPanel();
		panel.setVisible(true);
		panel.setBounds(0, 0, 1000, 1000);
		panel.setLayout(null);
		this.add(panel);

		label=new JLabel("**MALL BILLING SYSTEM**");
		label.setBounds(450, 100, 300, 100);
		panel.add(label);

		GenerateBill=new JButton("Generate Bill");
		GenerateBill.setBounds(450, 200, 200, 70);
		GenerateBill.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				Generate_Bill frm = new Generate_Bill();
				panel.setVisible(false);
				frm.setLocationByPlatform(true);
				frm.pack();
				frm.setDefaultCloseOperation(EXIT_ON_CLOSE);
				frm.setVisible(true);
			}});
		panel.add(GenerateBill);

		ProductList=new JButton("Product List");
		ProductList.setBounds(450, 300, 200, 70);
		ProductList.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
						Product_List frm = new Product_List();
						panel.setVisible(false);
						frm.setLocationByPlatform(true);
						frm.pack();
						frm.setDefaultCloseOperation(EXIT_ON_CLOSE);
						frm.setVisible(true);
					}
				});
			}});
		panel.add(ProductList);


		Taxdata=new JButton("Tax Data");
		Taxdata.setBounds(450, 400, 200, 70);
		Taxdata.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
						Tax_Data frm = new Tax_Data();
						panel.setVisible(false);
						frm.setLocationByPlatform(true);
						frm.pack();
						frm.setDefaultCloseOperation(EXIT_ON_CLOSE);
						frm.setVisible(true);
					}
				});
			}});
		panel.add(Taxdata);

		BilledData=new JButton("Billed Data");
		BilledData.setBounds(450, 500, 200, 70);
		BilledData.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
						Billed_Data frm = new Billed_Data();
						panel.setVisible(false);
						frm.setLocationByPlatform(true);
						frm.pack();
						frm.setDefaultCloseOperation(EXIT_ON_CLOSE);
						frm.setVisible(true);
					}
				});
			}});
		panel.add(BilledData);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				MainPage frm = new MainPage();
				frm.setLocationByPlatform(true);
				frm.pack();
				frm.setDefaultCloseOperation(EXIT_ON_CLOSE);
				frm.setVisible(true);
				new MainPage().setVisible(true);
			}
		});
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		final CardLayout cart=new CardLayout();
		panel.setLayout(cart);
		//String cmd=e.getActionCommand();
		int flag=0;
		if (e.getSource() == GenerateBill /*&& cmd.equals("Open")*/) {
			System.out.println("Clicked on GenerateBill.");
			panel1.setBounds(0, 0, 1000, 1000);
			panel1.setLayout(null);
			panel1.setVisible(true);
			panel.add(GenerateBill,"one");
			Generate_Bill D=new Generate_Bill();
			D.createGUI();
			flag=1;
			getContentPane().removeAll();
			getContentPane().add(panel);
			validate();
		} 
		else if(e.getSource() == ProductList ){
			System.out.println("Clicked on ProductList.");
			panel2.setBounds(0, 0, 1000, 1000);
			panel2.setLayout(null);
			panel2.setVisible(true);
			//panel.setVisible(false);
			panel.add(ProductList,"two");
			Product_List s=new Product_List();
			s.createGUI();
			flag=1;
			getContentPane().removeAll();
			getContentPane().add(panel);
			validate();
		}
		else if(e.getSource() == Taxdata ){
			System.out.println("Clicked on Taxdata.");
			panel3.setBounds(0, 0, 1000, 1000);
			panel3.setLayout(null);
			panel3.setVisible(true);
			//panel.setVisible(false);
			panel3.add(Taxdata,"three");
			Tax_Data Sa=new Tax_Data();
			Sa.createGUI();
			flag=1;
			getContentPane().removeAll();
			getContentPane().add(panel);
			validate();
		}
		else if(e.getSource() == BilledData ){
			System.out.println("Clicked on BilledData.");
			panel4.setBounds(0, 0, 1000, 1000);
			panel4.setLayout(null);
			panel4.setVisible(true);
			panel.setVisible(false);
			panel4.add(BilledData,"three");
			Billed_Data Ap=new Billed_Data();
			Ap.createGUI();
			flag=1;
			getContentPane().removeAll();
			getContentPane().add(panel);
			validate();
		}
	}
}