



//Here is sample code for you. You can easily modify it according to your requirements.

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class Generate_Bill extends JFrame{private JTable GenerateBill;
private JButton btnAdd,Enter,Back;
private DefaultTableModel tableModel;
private JTextField txtField1;
private JTextField txtField2;

static final String JDBC_DRIVER="com.mysql.jdbc.Driver";
static final String DB_URL="jdbc:mysql://localhost:3306/dbms";
static final String USER="dbms";
static final String PASSWORD="Pornima@576";

String query,query2,query3,query4;
Statement stmt=null;
Statement stmt2=null;
Statement stmt3=null;
PreparedStatement pstmt=null;
PreparedStatement pstmt2=null;
PreparedStatement pstmt3=null;
Scanner scan=new Scanner(System.in);
ResultSet rs=null;
ResultSet rs2=null;
ResultSet rs3=null;
char y,more;
int id,quantity,bill_id;
float o_price,n_price,b_price,o_tax,n_tax,value = 0, bill_total = 0;
String name,bill_date,type,brand;

Generate_Bill() {
	createGUI();
}

public void createGUI() {
	try{
		Class.forName(JDBC_DRIVER);						//Checking for driver
		Connection conn=DriverManager.getConnection(DB_URL,USER,PASSWORD);
	this.setBounds(0, 0, 1000, 1000);
	this.setLayout(new BorderLayout());
	JScrollPane pane = new JScrollPane();
	GenerateBill = new JTable();
	pane.setViewportView(GenerateBill);
	txtField1 = new JTextField();
	txtField2 = new JTextField();
	JPanel eastPanel = new JPanel();
	JPanel southPanel=new JPanel();
	JPanel northPanel = new JPanel();
	add(northPanel, BorderLayout.NORTH);
	add(eastPanel, BorderLayout.EAST);
	add(pane,BorderLayout.CENTER);
	add(southPanel,BorderLayout.SOUTH);
	JLabel lblField1 = new JLabel("Product Name   ");
	JLabel lblField2 = new JLabel("Quantity   ");
	northPanel.add(lblField1);
	northPanel.add(txtField1);
	northPanel.add(lblField2);

	northPanel.add(txtField2);
	btnAdd = new JButton("Add");
	northPanel.add(btnAdd);
	txtField1.setPreferredSize(lblField1.getPreferredSize());
	txtField2.setPreferredSize(lblField2.getPreferredSize());
	//add(pane,BorderLayout.CENTER);
	tableModel = new DefaultTableModel(new Object[]{"Product Name","Quantity"},0);
	GenerateBill.setModel(tableModel);
	query="drop table temp;";
	stmt=conn.createStatement();
	stmt.execute(query);
	query="create table temp (name varchar(30),quantity int);";
	stmt=conn.createStatement();
	stmt.execute(query);
	btnAdd.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			try{
			int count = tableModel.getRowCount()+1;
			tableModel.addRow(new Object[]{txtField1.getText(),txtField2.getText()});
			query="insert into temp values(?,?)";
			pstmt=conn.prepareStatement(query);
			System.out.print("Product name - ");
			name=txtField1.getText();
			pstmt.setString(1,name);
			System.out.print("Quantity - ");
			quantity=Integer.parseInt(txtField2.getText().toString());
			pstmt.setInt(2,quantity);
			pstmt.executeUpdate();
			pstmt.close();
			}
			catch(SQLException se){
			System.out.println("Error in SQL syntax");
			se.printStackTrace();
		}
		finally{

		}

		}
	});

	Enter=new JButton("Generate Bill");
	Enter.setBounds(200,500,100,50);
	southPanel.add(Enter);
	Enter.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent arg0) {
			SwingUtilities.invokeLater(new Runnable() {
				@Override
				public void run() {
					Bill frm = new Bill();
					//.setVisible(false);
					frm.setLocationByPlatform(true);
					frm.pack();
					frm.setDefaultCloseOperation(EXIT_ON_CLOSE);
					frm.setVisible(true);
				}
			});
		}});

	Back=new JButton("Back ");
	Back.setBounds(200,500,100,50);
	southPanel.add(Back);
	Back.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			//  int count = tableModel.getRowCount()+1;
			// tableModel.addRow(new Object[]{txtField1.getText(),txtField2.getText()});
			MainPage last=new MainPage();
			last.panel.setVisible(true);

		}
	});
	}
	catch(ClassNotFoundException ce){
		System.out.println("Cannot find driver");
	}
	catch(SQLException se){
		System.out.println("Error in SQL syntax");
		se.printStackTrace();
	}
	finally{

	}
}

/*public static void main(String[] args) {
	SwingUtilities.invokeLater(new Runnable() {
		@Override
		public void run() {
			Generate_Bill frm = new Generate_Bill();
			frm.setLocationByPlatform(true);
			frm.pack();
			frm.setDefaultCloseOperation(EXIT_ON_CLOSE);
			frm.setVisible(true);
		}
	});
}*/
} 