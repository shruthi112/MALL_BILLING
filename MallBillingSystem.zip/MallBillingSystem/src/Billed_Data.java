

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class Billed_Data extends JFrame{
	private JTable Billing;
	private DefaultTableModel tableModel;
	private JButton Back;
	
	static final String JDBC_DRIVER="com.mysql.jdbc.Driver";
	static final String DB_URL="jdbc:mysql://localhost:3306/dbms";
	static final String USER="dbms";
	static final String PASSWORD="Pornima@576";
	
	String query,query2,query3,query4;
	Statement stmt=null;
	Statement stmt2=null;
	Statement stmt3=null;
	PreparedStatement pstmt=null;
	PreparedStatement pstmt2=null;
	PreparedStatement pstmt3=null;
	Scanner scan=new Scanner(System.in);
	ResultSet rs=null;
	ResultSet rs2=null;
	ResultSet rs3=null;
	char y,more;
	int id,quantity,bill_id;
	float o_price,n_price,b_price,o_tax,n_tax,value = 0, bill_total = 0;
	//LocalDate bill_date;
	String name,bill_date,type,brand;

	Billed_Data() {
		createGUI();
	}

	public void createGUI() {
		try{
			Class.forName(JDBC_DRIVER);						//Checking for driver
			Connection conn=DriverManager.getConnection(DB_URL,USER,PASSWORD);
		this.setBounds(0, 0, 1000, 1000);
		setLayout(new BorderLayout());
		JScrollPane pane = new JScrollPane();
		Billing = new JTable();
		pane.setViewportView(Billing);
		JPanel eastPanel = new JPanel();
		JPanel northPanel = new JPanel();
		
		add(northPanel, BorderLayout.NORTH);
		add(eastPanel, BorderLayout.EAST);
		add(pane,BorderLayout.CENTER);
		tableModel = new DefaultTableModel(new Object[]{"Bill no.","Bill Date","Bill Total"},0);
		Billing.setModel(tableModel);
		
		query="select * from bill;";
		stmt=conn.createStatement();
		rs=stmt.executeQuery(query);
		while(rs.next()){
			bill_id=rs.getInt("bill_id");
			bill_date=rs.getString("bill_date");
			bill_total=rs.getFloat("bill_amount");
			System.out.println(bill_id+" "+bill_date+" "+bill_total);
			int count = tableModel.getRowCount()+1;
			tableModel.addRow(new Object[]{bill_id,bill_date,bill_total});
		}
		System.out.println("Display of product table successfull.");
		stmt.close();

		Back=new JButton("Back ");
		Back.setBounds(200,500,100,50);

		this.add(Back,BorderLayout.SOUTH);
		Back.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				MainPage last=new MainPage();
				last.panel.setVisible(true);

			}
		});
		}
		catch(ClassNotFoundException ce){
			System.out.println("Cannot find driver");
		}
		catch(SQLException se){
			System.out.println("Error in SQL syntax");
			se.printStackTrace();
		}
		finally{

		}
	}

	/*public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				Billed_Data frm = new Billed_Data();
				frm.setLocationByPlatform(true);
				frm.pack();
				frm.setDefaultCloseOperation(EXIT_ON_CLOSE);
				frm.setVisible(true);
			}
		});
	}*/
} 