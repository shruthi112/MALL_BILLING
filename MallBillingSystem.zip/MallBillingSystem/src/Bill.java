

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class Bill extends JFrame{private JTable Bill;
private JButton done,Back;
private DefaultTableModel tableModel;
JTextField txtField1,txtField2;

static final String JDBC_DRIVER="com.mysql.jdbc.Driver";
static final String DB_URL="jdbc:mysql://localhost:3306/dbms";
static final String USER="dbms";
static final String PASSWORD="Pornima@576";

private static final DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

String query,query2,query3,query4;
Statement stmt=null;
Statement stmt2=null;
Statement stmt3=null;
PreparedStatement pstmt=null;
PreparedStatement pstmt2=null;
PreparedStatement pstmt3=null;
Scanner scan=new Scanner(System.in);
ResultSet rs=null;
ResultSet rs2=null;
ResultSet rs3=null;
char y,more;
int id,quantity,bill_id;
float o_price,n_price,b_price,o_tax,n_tax,value = 0, bill_total = 0;
//LocalDate bill_date;
String name,bill_date,type,brand;

Bill() {
	createGUI();
}
public void createGUI() {
	try{
		Class.forName(JDBC_DRIVER);						//Checking for driver
		Connection conn=DriverManager.getConnection(DB_URL,USER,PASSWORD);
	setLayout(new BorderLayout());
	this.setBounds(0, 0, 1000, 1000);
	JScrollPane pane = new JScrollPane();
	Bill = new JTable();
	pane.setViewportView(Bill);
	JPanel eastPanel = new JPanel();
	JPanel southPanel=new JPanel();
	JPanel northPanel = new JPanel();
	add(northPanel, BorderLayout.NORTH);
	add(eastPanel, BorderLayout.EAST);
	add(pane,BorderLayout.CENTER);
	add(southPanel,BorderLayout.SOUTH);
	tableModel = new DefaultTableModel(new Object[]{"Product Id","Product Name","Quantity","OldPrice","New Price","Total Value"},0);
	Bill.setModel(tableModel);
	txtField1 = new JTextField();
	txtField2 = new JTextField();

	JLabel lblField1 = new JLabel("Bill No:   ");
	lblField1.setBounds(100, 100, 50, 50);
	northPanel.add(lblField1);
	txtField1.setBounds(100, 100, 50, 50);

	northPanel.add(txtField1);
	JLabel lblField2 = new JLabel("Date:  ");
	lblField1.setBounds(100, 100, 50, 50);
	northPanel.add(lblField2);
	txtField2.setBounds(100, 100, 50, 50);

	northPanel.add(txtField2);
	
	Date date = new Date();
	bill_date=sdf.format(date);
    bill_id=3456;
    txtField2.setText(bill_date);
    query="select bill_id from bill order by bill_id desc limit 1;";
    stmt=conn.createStatement();
    rs=stmt.executeQuery(query);
    if(rs.next()){
    	txtField1.setText(Integer.toString(rs.getInt("bill_id")+1));
    }
   
	//System.out.println("Bill no. "+bill_id+"    Bill Date"+sdf.format(date));
	bill_total=0;
	query="select name,quantity from temp;";
	stmt=conn.createStatement();
	rs=stmt.executeQuery(query);
	
	while(rs.next()){
		quantity=rs.getInt("quantity");
		name=rs.getString("name");
		query2="select id,Old_Price from Product where Product.name=?;";
		pstmt2=conn.prepareStatement(query2);
		pstmt2.setString(1,name);
		rs2=pstmt2.executeQuery();
		 System.out.println("hi");
		if(rs2.next()){
			id=rs2.getInt("id");
			o_price=rs2.getFloat("Old_Price");
			query3="select Old_tax,GST_tax from Tax where Tax.id=?;";
			pstmt3=conn.prepareStatement(query3);
			pstmt3.setInt(1,id);
			rs3=pstmt3.executeQuery();
			if(rs3.next()){
				n_tax=rs3.getFloat("GST_tax");
				o_tax=rs3.getFloat("Old_tax");
				n_price=(o_price*100/(100+o_tax))+(o_price*100/(100+o_tax))*n_tax/100;
				value=n_price*quantity;
				int count = tableModel.getRowCount()+1;
				tableModel.addRow(new Object[]{id,name,quantity,o_price,n_price,value});
				System.out.println(id+" "+name+" "+quantity+" "+o_price+" "+n_price+" "+value);
				bill_total=bill_total+value;
			}else{
				System.out.println("Taxes not found.");
			}
		}else{
			System.out.println("Product does not exists.");
		}
	}
	System.out.println("Bill Total = "+bill_total);
	int count = tableModel.getRowCount()+1;
	tableModel.addRow(new Object[]{null,null,null,null,null,null});
	
	count = tableModel.getRowCount()+1;
	tableModel.addRow(new Object[]{null,"Total",null,null,null,bill_total});

	done=new JButton("Done");
	done.setBounds(200,500,100,50);
	southPanel.add(done);
	done.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			try{
			query4="insert into bill (bill_date,bill_amount) values (?,?);";
			pstmt=conn.prepareStatement(query4);
			//pstmt.setInt(1,bill_id);
			pstmt.setString(1,bill_date);
			pstmt.setFloat(2,bill_total);
			pstmt.executeUpdate();
			System.out.println("Bill generation successfull.");
			pstmt.close();
		}
		catch(SQLException se){
			System.out.println("Error in SQL syntax");
			se.printStackTrace();
		}
		finally{

		}
			
		}
		
	});
	

	Back=new JButton("Back");
	Back.setBounds(200,500,100,50);
	southPanel.add(Back);
	Back.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			MainPage last=new MainPage();
			last.panel.setVisible(true);

		}
	});
	}
	catch(ClassNotFoundException ce){
		System.out.println("Cannot find driver");
	}
	catch(SQLException se){
		System.out.println("Error in SQL syntax");
		se.printStackTrace();
	}
	finally{

	}
}

/*public static void main(String[] args) {
	SwingUtilities.invokeLater(new Runnable() {
		@Override
		public void run() {
			Bill frm = new Bill();
			frm.setLocationByPlatform(true);
			frm.pack();
			frm.setDefaultCloseOperation(EXIT_ON_CLOSE);
			frm.setVisible(true);
		}
	});
}*/
} 
