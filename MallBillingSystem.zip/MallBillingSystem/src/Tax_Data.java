
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class Tax_Data extends JFrame{private JTable TaxData;
private JButton Back;
private DefaultTableModel tableModel;
//private JTextField txtField1;
//private JTextField txtField2;
//private JTextField txtField3;
//private JTextField txtField4;
//private JTextField txtField5;

static final String JDBC_DRIVER="com.mysql.jdbc.Driver";
static final String DB_URL="jdbc:mysql://localhost:3306/dbms";
static final String USER="dbms";
static final String PASSWORD="Pornima@576";

String query,query2,query3,query4;
Statement stmt=null;
Statement stmt2=null;
Statement stmt3=null;
PreparedStatement pstmt=null;
PreparedStatement pstmt2=null;
PreparedStatement pstmt3=null;
Scanner scan=new Scanner(System.in);
ResultSet rs=null;
ResultSet rs2=null;
ResultSet rs3=null;
char y,more;
int id,quantity,bill_id;
float o_price,n_price,b_price,o_tax,n_tax,value = 0, bill_total = 0;
//LocalDate bill_date;
String name,bill_date,type,brand;

Tax_Data() {
	createGUI();
}

public void createGUI() {
	try{
		Class.forName(JDBC_DRIVER);						//Checking for driver
		Connection conn=DriverManager.getConnection(DB_URL,USER,PASSWORD);
	this.setBounds(0, 0, 1000, 1000);
	setLayout(new BorderLayout());
	JScrollPane pane = new JScrollPane();
	TaxData = new JTable();
	pane.setViewportView(TaxData);
	JPanel eastPanel = new JPanel();
	JPanel southPanel=new JPanel();
	JPanel northPanel = new JPanel();
//	txtField1 = new JTextField();
//	txtField2 = new JTextField();
//	txtField3 = new JTextField();
//	txtField4 = new JTextField();
//	txtField5 = new JTextField();


//	JLabel lblField1 = new JLabel("Product Id  ");
//	JLabel lblField2 = new JLabel("Product Name    ");
//	JLabel lblField3 = new JLabel("Base Price   ");
//	JLabel lblField4 = new JLabel("OldTax   ");
//	JLabel lblField5 = new JLabel("GSTTax   ");

//	northPanel.add(lblField1);
//	northPanel.add(txtField1);
//	northPanel.add(lblField2);
//	northPanel.add(txtField2);
//	northPanel.add(lblField3);
//	northPanel.add(txtField3);
//	northPanel.add(lblField4);
//	northPanel.add(txtField4);
//	northPanel.add(lblField5);
//	northPanel.add(txtField5);
//	btnAdd = new JButton("Add");
//	northPanel.add(btnAdd);
//	txtField1.setPreferredSize(lblField1.getPreferredSize());
//	txtField2.setPreferredSize(lblField2.getPreferredSize());
//	txtField3.setPreferredSize(lblField3.getPreferredSize());
//	txtField4.setPreferredSize(lblField4.getPreferredSize());
//	txtField5.setPreferredSize(lblField5.getPreferredSize());

	add(northPanel, BorderLayout.NORTH);
	add(eastPanel, BorderLayout.EAST);
	add(pane,BorderLayout.CENTER);
	add(southPanel,BorderLayout.SOUTH);
	tableModel = new DefaultTableModel(new Object[]{"Product Id","Product Name","Base Price","OldTax","GSTTax"},0);
	TaxData.setModel(tableModel);
	
	query2="select id,name,Old_price from Product;";
	stmt=conn.createStatement();
	rs=stmt.executeQuery(query2);
	while(rs.next()){
		id=rs.getInt("id");
		name=rs.getString("name");
		o_price=rs.getFloat("Old_price");
		query3="select Old_tax,GST_tax from Tax where Tax.id=?;";
		pstmt3=conn.prepareStatement(query3);
		pstmt3.setInt(1,id);
		rs3=pstmt3.executeQuery();
		if(rs3.next()){
			n_tax=rs3.getFloat("GST_tax");
			o_tax=rs3.getFloat("Old_tax");
			b_price=o_price*100/(100+o_tax);
			
			System.out.println(id+" "+name+" "+b_price+" "+o_tax+" "+n_tax);
			int count = tableModel.getRowCount()+1;
			tableModel.addRow(new Object[]{id,name,b_price,o_tax,n_tax});
		
			bill_total=bill_total+value;
		}else{
			System.out.println("Taxes not found.");
		}
		
	}				
	System.out.println("tax table diplay successfully.");
	
	Back=new JButton("Back");
	Back.setBounds(200,500,100,50);
	southPanel.add(Back);
	Back.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
			MainPage last=new MainPage();
			last.panel.setVisible(true);

		}
	});
	}
	catch(ClassNotFoundException ce){
		System.out.println("Cannot find driver");
	}
	catch(SQLException se){
		System.out.println("Error in SQL syntax");
		se.printStackTrace();
	}
	finally{

	}
}

/*public static void main(String[] args) {
	SwingUtilities.invokeLater(new Runnable() {
		@Override
		public void run() {
			Tax_Data frm = new Tax_Data();
			frm.setLocationByPlatform(true);
			frm.pack();
			frm.setDefaultCloseOperation(EXIT_ON_CLOSE);
			frm.setVisible(true);
		}
	});
}*/
} 